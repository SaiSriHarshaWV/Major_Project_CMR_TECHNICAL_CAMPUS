package com.deva.mvsr.trekker;

public class Constants {

	public static final String ACCESS_KEY_ID = "AKIAJ4JV2H4KO5YZ662A";
	public static final String SECRET_KEY = "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";

}
